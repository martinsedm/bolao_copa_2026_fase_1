import streamlit as st
from data import load_data, compute_standings, PARTICIPANTS, calc_points
from style import inject_style, show_header

st.set_page_config(
    page_title="Bolão Copa 2026",
    page_icon="⚽",
    layout="wide",
    initial_sidebar_state="collapsed",
)

inject_style()
show_header()

data = load_data()

scoring = data.get("scoring", {
    "exact_score": 6,
    "one_goal_and_winner": 4,
    "winner_and_one_goal": 3,
    "winner_only": 1
})
# ── Tabs ─────────────────────────────────────────────────────────────────────
tab_rank, tab_jogos, tab_palpites = st.tabs(["🏆  Classificação", "⚽  Jogos", "📋  Palpites"])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 – CLASSIFICAÇÃO
# ══════════════════════════════════════════════════════════════════════════════
with tab_rank:
    standings = compute_standings(data)
    total_games = len(data["games"])
    played = sum(1 for g in data["games"] if g["result_g1"] is not None)

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f'<div class="stat-card"><div class="stat-num">{played}</div><div class="stat-lbl">Jogos com resultado</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="stat-card"><div class="stat-num">{total_games - played}</div><div class="stat-lbl">Jogos restantes</div></div>', unsafe_allow_html=True)
    with c3:
        leader_pts = standings[0]["total"] if standings else 0
        st.markdown(f'<div class="stat-card"><div class="stat-num">{leader_pts}</div><div class="stat-lbl">Pontos do líder</div></div>', unsafe_allow_html=True)
    with c4:
        pct = int(played / total_games * 100) if total_games else 0
        st.markdown(f'<div class="stat-card"><div class="stat-num">{pct}%</div><div class="stat-lbl">Progresso</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    medals = {1: "🥇", 2: "🥈", 3: "🥉"}
    rows = ""
    for s in standings:
        medal = medals.get(s["rank"], f"{s['rank']}º")
        top_cls = "top3" if s["rank"] <= 3 else ""
        pts_html = f'<span class="pts-badge">{s["total"]}</span>'
        rows += (
            f'<tr class="{top_cls}">'
            f'<td><span class="medal">{medal}</span></td>'
            f'<td>{s["name"]}</td>'
            f'<td>{pts_html}</td>'
            f'<td>{s["pts6"]}</td>'
            f'<td>{s["pts4"]}</td>'
            f'<td>{s["pts3"]}</td>'
            f'<td>{s["pts1"]}</td>'
            f'<td>{s["brasil"]}</td>'
            f'</tr>'
        )

    table_html = (
        '<table class="rank-table">'
        '<thead><tr>'
        '<th>#</th>'
        '<th style="text-align:left">Participante</th>'
        '<th>Total</th>'
        '<th>6pts</th>'
        '<th>4pts</th>'
        '<th>3pts</th>'
        '<th>1pt</th>'
        '<th>Brasil</th>'
        '</tr></thead>'
        f'<tbody>{rows}</tbody>'
        '</table>'
        '<br>'
        '<small style="color: #6c757d;">'
        '⭐ Placar exato (6 pts) &nbsp;|&nbsp; 🎯 Um gol + vencedor (4 pts) &nbsp;|&nbsp; '
        '✅ Vencedor + um gol (3 pts) &nbsp;|&nbsp; 👍 Só vencedor (1 pt) &nbsp;|&nbsp; '
        '🇧🇷 Pontos em jogos do Brasil (desempate)'
        '</small>'
    )
    st.markdown(table_html, unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 – JOGOS
# ══════════════════════════════════════════════════════════════════════════════
with tab_jogos:
    col_f1, col_f2 = st.columns([1, 2])
    with col_f1:
        filter_status = st.selectbox(
            "Filtrar por status",
            ["Todos", "Com resultado", "Sem resultado", "Jogos do Brasil"],
            label_visibility="collapsed"
        )
    with col_f2:
        search = st.text_input("Buscar time...", placeholder="Ex: Brasil, Argentina", label_visibility="collapsed")

    days = {}
    for g in data["games"]:
        d = g["dia"]
        days.setdefault(d, []).append(g)

    for day in sorted(days.keys()):
        games_in_day = days[day]

        filtered = []
        for g in games_in_day:
            if filter_status == "Com resultado" and g["result_g1"] is None:
                continue
            if filter_status == "Sem resultado" and g["result_g1"] is not None:
                continue
            if filter_status == "Jogos do Brasil" and not g["is_brasil"]:
                continue
            if search and search.lower() not in g["pais1"].lower() and search.lower() not in g["pais2"].lower():
                continue
            filtered.append(g)

        if not filtered:
            continue

        st.markdown(f"**📅 Dia {day} de junho**")

        for g in filtered:
            has_result = g["result_g1"] is not None
            is_brasil = g["is_brasil"]
            cls = "is-brasil" if is_brasil else ("has-result" if has_result else "")

            if has_result:
                score_html = f'<div class="score-box final">{g["result_g1"]} × {g["result_g2"]}</div>'
            else:
                score_html = '<div class="score-box">— × —</div>'

            brasil_flag = " 🇧🇷" if is_brasil else ""
            status_html = (
                "<small style='color:#198754;font-size:.75rem'>✓ resultado registrado</small>"
                if has_result else
                "<small style='color:#aaa;font-size:.75rem'>aguardando</small>"
            )
            card_html = (
                f'<div class="game-card {cls}">'
                f'<span class="day-badge">Jogo {g["id"]+1}</span>'
                f'<span class="team-name">{g["pais1"]}{brasil_flag if g["pais1"]=="Brasil" else ""}</span>'
                f'{score_html}'
                f'<span class="team-name">{g["pais2"]}{brasil_flag if g["pais2"]=="Brasil" else ""}</span>'
                f'{status_html}'
                f'</div>'
            )
            st.markdown(card_html, unsafe_allow_html=True)

        st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 – PALPITES
# ══════════════════════════════════════════════════════════════════════════════
with tab_palpites:
    st.markdown("Veja os palpites de cada participante e a pontuação obtida até agora.")

    col_p, col_g = st.columns([1, 2])
    with col_p:
        selected_p = st.selectbox("Participante", PARTICIPANTS)
    with col_g:
        filter_g = st.selectbox(
            "Jogos",
            ["Todos os jogos", "Jogos com resultado", "Jogos sem resultado", "Jogos do Brasil"],
            label_visibility="collapsed"
        )

    total_pts = 0
    rows_html = ""

    for g in data["games"]:
        has_result = g["result_g1"] is not None
        if filter_g == "Jogos com resultado" and not has_result:
            continue
        if filter_g == "Jogos sem resultado" and has_result:
            continue
        if filter_g == "Jogos do Brasil" and not g["is_brasil"]:
            continue

        bet = g["bets"].get(selected_p, {})
        b1, b2 = bet.get("g1", "?"), bet.get("g2", "?")
        pts = calc_points(
	    g["result_g1"],
	    g["result_g2"],
	    b1,
	    b2,
	    scoring
	) if has_result else None
        total_pts += pts if pts else 0

        if has_result:
            result_str = f"{g['result_g1']} × {g['result_g2']}"
            pts_cls = f"pts-{pts}" if pts is not None else "pts-0"
            pts_lbl = f'<span class="pts-chip {pts_cls}">{pts} pt{"s" if pts != 1 else ""}</span>'
        else:
            result_str = "— × —"
            pts_lbl = '<span style="color:#aaa;font-size:.78rem">pendente</span>'

        brasil_icon = " 🇧🇷" if g["is_brasil"] else ""
        rows_html += (
            f'<div class="bet-row">'
            f'<span style="width:28px;color:#aaa;font-size:.78rem">{g["id"]+1}</span>'
            f'<span style="flex:1;font-size:.85rem">{g["pais1"]} × {g["pais2"]}{brasil_icon}</span>'
            f'<span class="bet-score">{b1} × {b2}</span>'
            f'<span style="width:70px;text-align:center;font-size:.8rem;color:#6c757d">{result_str}</span>'
            f'{pts_lbl}'
            f'</div>'
        )

    pct_done = int(sum(1 for g in data["games"] if g["result_g1"] is not None) / len(data["games"]) * 100)

    final_html = (
        f'<div style="display:flex;align-items:center;gap:16px;margin-bottom:12px">'
        f'<div>'
        f'<div style="font-size:.8rem;color:#6c757d;text-transform:uppercase;letter-spacing:.5px">Total de pontos</div>'
        f'<div style="font-size:2rem;font-weight:700;color:#002776">{total_pts} pts</div>'
        f'</div>'
        f'<div style="flex:1">'
        f'<div style="font-size:.78rem;color:#6c757d">Progresso do torneio: {pct_done}%</div>'
        f'<div class="progress-wrap"><div class="progress-fill" style="width:{pct_done}%"></div></div>'
        f'</div>'
        f'</div>'
        f'<div style="background:#fff;border:1px solid #dee2e6;border-radius:10px;padding:12px 16px">'
        f'<div style="display:flex;gap:10px;padding-bottom:8px;border-bottom:2px solid #f1f3f5;font-size:.75rem;font-weight:700;color:#6c757d;text-transform:uppercase;letter-spacing:.5px">'
        f'<span style="width:28px">#</span>'
        f'<span style="flex:1">Jogo</span>'
        f'<span style="width:60px;text-align:center">Palpite</span>'
        f'<span style="width:70px;text-align:center">Resultado</span>'
        f'<span style="width:60px;text-align:center">Pontos</span>'
        f'</div>'
        f'{rows_html if rows_html else "<div style=\'color:#aaa;text-align:center;padding:20px\'>Nenhum jogo encontrado.</div>"}'
        f'</div>'
    )
    st.markdown(final_html, unsafe_allow_html=True)
